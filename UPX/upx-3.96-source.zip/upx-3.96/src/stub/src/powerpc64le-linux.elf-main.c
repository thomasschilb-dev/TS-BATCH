#ifndef BIG_ENDIAN  //{
#define BIG_ENDIAN 0
#endif  //}
#include "amd64-linux.elf-main.c"
