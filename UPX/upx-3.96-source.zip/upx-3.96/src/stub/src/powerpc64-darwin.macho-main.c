#define BIG_ENDIAN 1
#include "powerpc64le-darwin.macho-main.c"
