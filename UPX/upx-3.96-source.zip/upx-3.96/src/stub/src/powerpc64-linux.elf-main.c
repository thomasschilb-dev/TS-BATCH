#ifndef BIG_ENDIAN  //{
#define BIG_ENDIAN 1
#endif  //}
#include "powerpc64le-linux.elf-main.c"
