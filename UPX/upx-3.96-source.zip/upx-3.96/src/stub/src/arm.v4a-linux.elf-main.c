#include "i386-linux.elf-main.c"

/* vim:set ts=4 sw=4 et: */
